import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { Camera, Flashlight, FlashlightOff, CircleDot, Save, RotateCcw, AlertTriangle, Info } from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import DisclaimerBanner from '../components/shared/DisclaimerBanner';
import { base44 } from '@/api/base44Client';

export default function LensScanner() {
  const [isScanning, setIsScanning] = useState(false);
  const [flashOn, setFlashOn] = useState(false);
  const [sensitivity, setSensitivity] = useState([50]);
  const [reflections, setReflections] = useState([]);
  const [showResults, setShowResults] = useState(false);
  const [cameraPermission, setCameraPermission] = useState('unknown');
  const [sessionId, setSessionId] = useState(null);
  const scanTimerRef = useRef(null);

  const { data: user } = useQuery({
    queryKey: ['me'],
    queryFn: () => base44.auth.me(),
  });

  // Check camera permission
  useEffect(() => {
    if (navigator.permissions && navigator.permissions.query) {
      navigator.permissions.query({ name: 'camera' })
        .then(result => {
          setCameraPermission(result.state);
          result.onchange = () => setCameraPermission(result.state);
        })
        .catch(() => setCameraPermission('prompt'));
    }
  }, []);

  const startScan = () => {
    if (cameraPermission === 'denied') {
      alert('Camera access denied. Please enable camera permissions in your device settings.');
      return;
    }

    setIsScanning(true);
    setReflections([]);
    setShowResults(false);
    setSessionId(null);

    // Simulate finding reflections
    let count = 0;
    let foundReflections = [];
    scanTimerRef.current = setInterval(() => {
      count++;
      if (Math.random() > 0.6) {
        const newReflection = {
          id: Date.now(),
          x: Math.random() * 80 + 10,
          y: Math.random() * 60 + 20,
          intensity: Math.random() * 100,
        };
        foundReflections.push(newReflection);
        setReflections(prev => [...prev, newReflection]);
      }
      if (count >= 15) {
        clearInterval(scanTimerRef.current);
        setIsScanning(false);
        setShowResults(true);

        // Save scan session
        if (user?.id) {
          base44.entities.ScanSession.create({
            user_id: user.id,
            scan_type: 'lens',
            status: 'completed',
            duration_seconds: 15,
            findings_count: foundReflections.length,
          }).then(session => setSessionId(session.id))
            .catch(() => {});
        }
      }
    }, 1000);
  };

  useEffect(() => {
    return () => {
      if (scanTimerRef.current) clearInterval(scanTimerRef.current);
    };
  }, []);

  const saveFindings = async () => {
    if (!user?.id || !sessionId) return;

    try {
      for (const r of reflections) {
        await base44.entities.SuspiciousFinding.create({
          user_id: user.id,
          scan_session_id: sessionId,
          finding_type: 'lens_reflection',
          severity: r.intensity > 70 ? 'high' : r.intensity > 40 ? 'medium' : 'low',
          title: `Reflection at ${Math.round(r.x)}%, ${Math.round(r.y)}%`,
          description: `Intensity: ${Math.round(r.intensity)}%. May be camera lens, LED, or reflective surface.`,
          location_description: `Position: ${Math.round(r.x)}% horizontal, ${Math.round(r.y)}% vertical`,
        });
      }
      alert('Findings saved successfully');
    } catch (error) {
      console.error('Failed to save findings:', error);
      alert('Failed to save findings');
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <div className="px-5 py-4 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-[#00BFFF]/10 flex items-center justify-center">
          <Camera className="w-5 h-5 text-[#00BFFF]" />
        </div>
        <div>
          <h1 className="text-lg font-bold">Lens Scanner</h1>
          <p className="text-xs text-[#5A6A80]">Detect camera lens reflections</p>
        </div>
      </div>

      {/* Camera View Area */}
      <div className="relative mx-5 rounded-2xl overflow-hidden bg-[#0a0e13] border border-[#2A3A50] aspect-[3/4]">
        {/* Simulated camera view */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a0e13] to-[#121820]" />

        {/* Scan overlay */}
        {isScanning && (
          <>
            {/* Scanning line */}
            <motion.div
              className="absolute left-0 right-0 h-0.5 bg-[#00BFFF] shadow-[0_0_12px_rgba(0,191,255,0.8)]"
              animate={{ top: ['0%', '100%'] }}
              transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
            />
            {/* Grid */}
            <div className="absolute inset-0 opacity-10" style={{
              backgroundImage: 'linear-gradient(#00BFFF 1px, transparent 1px), linear-gradient(90deg, #00BFFF 1px, transparent 1px)',
              backgroundSize: '40px 40px',
            }} />
            {/* Corner brackets */}
            <div className="absolute top-4 left-4 w-8 h-8 border-t-2 border-l-2 border-[#00BFFF] rounded-tl" />
            <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-[#00BFFF] rounded-tr" />
            <div className="absolute bottom-4 left-4 w-8 h-8 border-b-2 border-l-2 border-[#00BFFF] rounded-bl" />
            <div className="absolute bottom-4 right-4 w-8 h-8 border-b-2 border-r-2 border-[#00BFFF] rounded-br" />
          </>
        )}

        {/* Reflection Points */}
        <AnimatePresence>
          {reflections.map((r) => (
            <motion.div
              key={r.id}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              className="absolute"
              style={{ left: `${r.x}%`, top: `${r.y}%` }}
            >
              <div className="relative">
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                  r.intensity > 70 ? 'border-red-400 bg-red-400/20' : 'border-amber-400 bg-amber-400/20'
                }`}>
                  <div className={`w-2 h-2 rounded-full ${
                    r.intensity > 70 ? 'bg-red-400' : 'bg-amber-400'
                  }`} />
                </div>
                <motion.div
                  className={`absolute inset-0 rounded-full ${
                    r.intensity > 70 ? 'border border-red-400/50' : 'border border-amber-400/50'
                  }`}
                  animate={{ scale: [1, 1.8], opacity: [0.5, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                />
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Instruction text */}
        {isScanning && (
          <div className="absolute bottom-8 left-0 right-0 text-center px-6">
            <div className="bg-black/70 backdrop-blur-sm px-5 py-3 rounded-2xl inline-block border border-[#00BFFF]/20">
              <p className="text-sm text-[#00BFFF] font-medium">Move slowly across the room</p>
              <p className="text-xs text-[#5A6A80] mt-1">Lenses reflect light</p>
            </div>
          </div>
        )}

        {!isScanning && !showResults && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center px-6">
              <Camera className="w-12 h-12 text-[#5A6A80] mx-auto mb-3" />
              <p className="text-sm text-[#5A6A80]">
                {cameraPermission === 'denied' 
                  ? 'Camera access denied. Enable in settings.' 
                  : 'Tap "Start Scan" to begin'}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="px-5 py-4 space-y-4">
        {/* Flashlight + Sensitivity */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => setFlashOn(!flashOn)}
            className={`w-12 h-12 rounded-xl flex items-center justify-center border transition-all ${
              flashOn
                ? 'bg-amber-400/10 border-amber-400/30 text-amber-400'
                : 'bg-[#1A2332] border-[#2A3A50] text-[#5A6A80]'
            }`}
          >
            {flashOn ? <Flashlight className="w-5 h-5" /> : <FlashlightOff className="w-5 h-5" />}
          </button>
          <div className="flex-1">
            <p className="text-xs text-[#5A6A80] mb-1.5">Sensitivity</p>
            <Slider
              value={sensitivity}
              onValueChange={setSensitivity}
              max={100}
              step={1}
              className="w-full"
            />
          </div>
        </div>

        {/* Scan Button */}
        {!showResults && (
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={startScan}
            disabled={isScanning}
            className={`w-full py-4 rounded-2xl font-semibold text-base transition-all ${
              isScanning
                ? 'bg-[#243044] text-[#5A6A80]'
                : 'bg-[#00BFFF] text-[#0F1419] shadow-lg shadow-[#00BFFF]/20'
            }`}
          >
            {isScanning ? (
              <span className="flex items-center justify-center gap-2">
                <CircleDot className="w-5 h-5 animate-pulse" /> Scanning...
              </span>
            ) : (
              <span className="flex items-center justify-center gap-2">
                <Camera className="w-5 h-5" /> Start Scan
              </span>
            )}
          </motion.button>
        )}

        {/* Results Summary */}
        {showResults && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <div className={`p-5 rounded-2xl border ${
              reflections.length > 0
                ? 'bg-amber-500/8 border-amber-500/30'
                : 'bg-emerald-500/8 border-emerald-500/30'
            }`}>
              {reflections.length > 0 ? (
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center shrink-0">
                    <AlertTriangle className="w-6 h-6 text-amber-400" />
                  </div>
                  <div>
                    <p className="font-bold text-base mb-1">{reflections.length} Reflection{reflections.length > 1 ? 's' : ''} Detected</p>
                    <p className="text-sm text-[#8B9BB4] leading-relaxed">Physically inspect each bright spot. May be LEDs, glass, or reflective surfaces.</p>
                  </div>
                </div>
              ) : (
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center shrink-0">
                    <Camera className="w-6 h-6 text-emerald-400" />
                  </div>
                  <div>
                    <p className="font-bold text-base">Scan Complete</p>
                    <p className="text-sm text-[#8B9BB4] mt-1">No obvious reflections found</p>
                  </div>
                </div>
              )}
            </div>

            <div className="flex gap-3">
              {reflections.length > 0 && (
                <button
                  onClick={saveFindings}
                  className="flex-1 py-3 rounded-2xl bg-[#1A2332] border border-[#2A3A50] text-sm font-medium text-[#8B9BB4] flex items-center justify-center gap-2"
                >
                  <Save className="w-4 h-4" /> Save Findings
                </button>
              )}
              <button
                onClick={() => { setShowResults(false); setReflections([]); }}
                className="flex-1 py-3 rounded-2xl bg-[#1A2332] border border-[#2A3A50] text-sm font-medium text-[#8B9BB4] flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-4 h-4" /> Rescan
              </button>
            </div>

            <div className="flex items-start gap-3 p-4 rounded-xl bg-[#243044]/40 border border-[#2A3A50]">
              <Info className="w-5 h-5 text-[#5A6A80] mt-0.5 shrink-0" />
              <p className="text-xs text-[#8B9BB4] leading-relaxed">Visual assistance only. Reflections can be LEDs, mirrors, or glass. Manually verify suspicious areas.</p>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}